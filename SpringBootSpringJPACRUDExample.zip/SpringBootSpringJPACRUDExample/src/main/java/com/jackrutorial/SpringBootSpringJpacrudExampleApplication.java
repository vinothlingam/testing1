package com.jackrutorial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootSpringJpacrudExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootSpringJpacrudExampleApplication.class, args);
	}

}

